# Creation of an application-temperature meter (web and mobile).
##### I'll explain step by step part: Embedded, MQTT server, socket, web and app. [Talk](https://goo.gl/meh3Vi)
Wait for the tutorial.

If you enjoyed it, leave a star, which encourages us to accelerate the project =D




# Criação de uma aplicação - medidor de temperatura(Web e Mobile) .
##### Vou explicar passo a passo a parte: Embarcado , servidor de Mqtt, Socket, Web e App. [Palestra](https://goo.gl/meh3Vi)

Em breve o passo a passo.

Se gostou, deixa uma star, isso nos incentiva a dar um gás no proje
